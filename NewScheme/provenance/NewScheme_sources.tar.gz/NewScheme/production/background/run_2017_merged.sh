#!/bin/bash
set -eo pipefail
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
source /scratchfs2/cms/liugeliang/miniconda3/bin/activate unbin
cd /cms/user/liugeliang/CMS/HZZAnalysis/FitTemplate/jobs/reduced_20261009_pnet
/scratchfs2/cms/liugeliang/miniconda3/envs/unbin/bin/python -u produce_reduced_stream.py --era 2017 --cat merged --config-dir cards --sf-dir sf --output-dir /cms/user/liugeliang/CMS/HZZAnalysis/FitTemplate/RedTrees_20261009_pnet --step-size 100000
